function tau = InitializePheromoneLevels(numberOfNodes, tau0)

  tau = repmat(tau0, numberOfNodes);

end

