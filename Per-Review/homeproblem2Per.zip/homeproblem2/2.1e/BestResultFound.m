% Best result from ACO-rpogram, this run gave a path length of 122,3858 unit of length.

bestPath = [26 23 19 16 22 29 32 36 40 48 46 47 44 41 39 42 45 50 49 43 37 ...
  38 35 27 15 9 1 5 4 2 10 11 21 24 31 34 33 25 18 12 6 3 7 8 13 14 17 20 28 30];