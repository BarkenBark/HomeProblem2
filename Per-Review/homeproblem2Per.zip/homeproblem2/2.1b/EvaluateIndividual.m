function f = EvaluateIndividual(x)

f = 1/x;

end

