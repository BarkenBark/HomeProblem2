function [ population ] = InitializePopulation( populationSize, nGenes )

population = rand(populationSize, nGenes);

end

