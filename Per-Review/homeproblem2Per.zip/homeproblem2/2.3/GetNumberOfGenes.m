function numberOfGenes = GetNumberOfGenes( numberOfNeurons )

numberOfGenes = 3*numberOfNeurons + numberOfNeurons + 2*numberOfNeurons + 2;


end

